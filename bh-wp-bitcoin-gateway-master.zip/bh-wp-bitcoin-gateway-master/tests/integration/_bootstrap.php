<?php
/**
 * Runs after WordPress has been initialised (after plugins are loaded) and before tests are run.
 *
 * @package    brianhenryie/bh-wp-bitcoin-gateway
 */
