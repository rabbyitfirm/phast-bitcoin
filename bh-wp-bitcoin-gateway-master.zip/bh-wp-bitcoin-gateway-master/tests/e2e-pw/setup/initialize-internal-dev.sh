#!/bin/bash

# Print the script name.
echo $(basename "$0")

// Nothing to do.