<?php
/**
 * PHPUnit bootstrap file for contract tests.
 * Tests which interact with live APIs.
 *
 * @package    brianhenryie/bh-wp-bitcoin-gateway
 */

global $plugin_root_dir;
require_once $plugin_root_dir . '/autoload.php';
