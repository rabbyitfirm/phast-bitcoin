<?php
/**
 * TODO: Removed *required on billing fields.
 *
 * @package    brianhenryie/bh-wp-bitcoin-gateway
 */
